package vn.edu.iuh.fit.service;

import vn.edu.iuh.fit.model.Message;

import java.util.List;

public interface MessageService {
    void sendMessage(Message message);
    List<Message> getMessages(String roomId);
}
